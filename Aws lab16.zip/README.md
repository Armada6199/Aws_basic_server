# cloud-server
![screen](./aaaa.png)
[deploed link](http://cloud-server-v2-env.eba-ge7a9pp6.us-east-1.elasticbeanstalk.com/)